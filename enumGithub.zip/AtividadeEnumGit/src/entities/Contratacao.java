package entities;

import java.util.Date;

public class Contratacao {
	private Date data;
	private Cargo cargo;
	private Status status;
			
	
	public Contratacao(Date data, Cargo cargo, Status status) {
		this.cargo = cargo;
		this.status = status;
		this.data = new Date();
		this.status = Status.PENDENTE;
		
	}
	public Contratacao(Date parse, Cargo diretor, Fucionario f1, Projeto p1) {
		
	}
	public void confirmar () {
		this.status = Status.PENDENTE;
	}
	public void contratar () {
		this.status = Status.CONTRATADO;
	}
	public void demitir () {
		this.status = Status.DEMITIDO;
	}
	
	public Date getData() {
		return data;
	}
	public Cargo getCargo() {
		return cargo;
	}
	public Status getStatus() {
		return status;
	}
	public Projeto getFucionario() {
		// TODO Auto-generated method stub
		return null;
	}
	
		
	
}
