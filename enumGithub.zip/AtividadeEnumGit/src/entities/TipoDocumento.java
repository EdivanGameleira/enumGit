package entities;

public enum TipoDocumento {
	RG("Registro geral"),
	CPF("Cadastro pessoa fisica"),
	CNPJ("Cadastro pssoa juridica");
	
	private String descricao;
	
	void Status (String descricao){
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return descricao;
	}
		
	private String TipoDocumento;
	
	TipoDocumento (String TipoDocumento){
		this.TipoDocumento = TipoDocumento;
	}
	
	private String getTipoDocumento() {
		return TipoDocumento;
	}
}
