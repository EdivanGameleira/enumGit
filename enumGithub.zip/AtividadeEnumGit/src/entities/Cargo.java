package entities;

public enum Cargo {
	DIRETOR,
	ANALISTA,
	ASSESOR,
	TECNICO,
	ADMINISTRATIVO;
	

}
