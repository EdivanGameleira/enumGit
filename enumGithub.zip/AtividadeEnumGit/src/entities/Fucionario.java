package entities;

import java.util.Objects;

public class Fucionario {
	private String nome;
	private String numeroDocumento;
	private TipoDocumento documento;
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public TipoDocumento getDocumento() {
		return documento;
	}

	public void setDocumento(TipoDocumento documento) {
		this.documento = documento;
	}

	public Fucionario(String nome, String numeroDocumento, TipoDocumento documento) {
		this.nome = nome;
		this.numeroDocumento = numeroDocumento;
		this.documento = documento;
	}

	@Override
	public int hashCode() {
		return Objects.hash(documento, nome, numeroDocumento);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fucionario other = (Fucionario) obj;
		return documento == other.documento && Objects.equals(nome, other.nome)
				&& Objects.equals(numeroDocumento, other.numeroDocumento);
	}

	@Override
	public String toString() {
		return "Fucionario [nome=" + nome + ", numeroDocumento=" + numeroDocumento + ", documento=" + documento + "]";
	}
	
	
}
