package entities;

public enum Status {
	PENDENTE("contratação aguaradando"),
	CONTRATADO("Funcionario contratado"),
	DEMITIDO("Funcionario demetido");
	
	private String descricao;
	
	Status (String descricao){
		this.descricao = descricao;
	}

	public String getDescricacao() {
		return descricao;
	}

		
}