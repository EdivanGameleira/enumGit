package entities;

import java.text.ParseException;
import java.text.SimpleDateFormat;


public class Program {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		Projeto p1 = new Projeto("Construcão da loja XYZ",df.parse("01/01/2022"), df.parse("31/02/2023"));
		Fucionario f1 = new Fucionario ("Dory","999.999.999-00",TipoDocumento.CPF);
		Fucionario f2 = new Fucionario ("Edivan","111.111.111-00",TipoDocumento.CPF);
		Contratacao c1 = new Contratacao(df.parse("01/01/2022"),Cargo.DIRETOR,f1,p1);
		Contratacao c2 = new Contratacao(df.parse("11/10/2022"),Cargo.ADMINISTRATIVO,f2,p1);
		
		p1.listarContratacao();
		
		c1.contratar();
		p1.listarContratacao();
		
		c1.demitir();
		c2.contratar();
		p1.listarContratacao();
		

	}

}
