package entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Projeto {
	private String nome;
	private Date dt_Inicio;
	private Date dt_Terminio;
	private List<Contratacao> listaContratacao = new ArrayList<>();
	
	public Projeto(String nome, Date dt_Inicio, Date dt_Terminio) {
		this.nome = nome;
		this.dt_Inicio = dt_Inicio;
		this.dt_Terminio = dt_Terminio;
		
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getDt_Inicio() {
		return dt_Inicio;
	}

	public void setDt_Inicio(Date dt_Inicio) {
		this.dt_Inicio = dt_Inicio;
	}

	public Date getDt_Terminio() {
		return dt_Terminio;
	}

	public void setDt_Terminio(Date dt_Terminio) {
		this.dt_Terminio = dt_Terminio;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dt_Inicio, dt_Terminio, nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Projeto other = (Projeto) obj;
		return Objects.equals(dt_Inicio, other.dt_Inicio) && Objects.equals(dt_Terminio, other.dt_Terminio)
				&& Objects.equals(nome, other.nome);
	}
	
	public boolean adicinarContratacao(Contratacao contratacao) {
		if(contratacao != null && !listaContratacao.contains(contratacao)) {
			this.listaContratacao.add(contratacao);
			return true;
		}
		return false;
	}
	public boolean removerContratacao(Contratacao contratacao) {
		if(contratacao != null && listaContratacao.size() > 0 && listaContratacao.contains(contratacao)) {
			listaContratacao.remove(contratacao);
			return true;
		}
		return false;
	}
	
	public void listarContratacao() {
		if(listaContratacao.isEmpty()) {
			System.out.println("Projeto "+this.nome+ "não tem nem o funcionario contratado");
		}
		System.out.println("Projeto:"+this.nome);
		for(Contratacao c: listaContratacao) {
			System.out.println("Fucionario"+c.getFucionario().getNome()
					+"(Status: "+c.getStatus().getDescricacao());
		}
		
	}

	@Override
	public String toString() {
		return "Projeto [nome=" + nome + ", dt_Inicio=" + dt_Inicio + ", dt_Terminio=" + dt_Terminio
				+ ", listaContratacao=" + listaContratacao + "]";
	}
}
